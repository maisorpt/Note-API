import React from 'react';


function NotFoundPage() {
  return (
    <div>
      <h1>404 Not Found</h1>
      <p>Halaman yang Anda cari tidak ditemukan.</p>
    </div>
  );
}

export default NotFoundPage;
