import React from 'react';
 
const LocalContext = React.createContext();
 
export default LocalContext;